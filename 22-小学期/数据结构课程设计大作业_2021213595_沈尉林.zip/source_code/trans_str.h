#pragma once
#include <iostream>  
#include <string>   
#include <windows.h> 
#include <winnls.h>

inline void Wchar_t_to_String(wchar_t* wchar, std::string& szDst)
{
	wchar_t* wText = wchar;
	DWORD dwNum = WideCharToMultiByte(CP_OEMCP, NULL, wText, -1, NULL, 0, NULL, FALSE);
	char* psText;
	psText = new char[dwNum];
	WideCharToMultiByte(CP_OEMCP, NULL, wText, -1, psText, dwNum, NULL, FALSE);
	szDst = psText;
	delete[]psText;
}