﻿// newbigwork.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#pragma once
#include <iostream>
#include"metro_graph.h"
#include"Users.h"
#include <graphics.h>		// 引用图形库头文件
#include <conio.h>
#include"Window.h"
#define DEBUG_MAIN
#define DEBUG_UI
int main()
{
#ifndef DEBUG_UI


    initgraph(960, 480);	// 创建绘图窗口，大小为 960x480 像素
    //设置背景颜色
    setbkcolor(WHITE);
    cleardevice();//清空窗口
    string text = "你好";
    settextcolor(RED);
    settextstyle(20, 0, "楷体");
    outtextxy(50, 50, "你好");

    setlinecolor(BLUE);//设置线条颜色
    setfillcolor(YELLOW);//设置填充颜色
    setbkmode(TRANSPARENT);//设置字体透明
    //设置字体居中
    char arr[] = "居中你好";
    int x = (100-textwidth(arr))/2;
    int y = (50-textheight(arr))/2;
    fillrectangle(200,50,300,100);
    outtextxy(x+200, y+50, arr);

    IMAGE img;
    


    _getch();				// 按任意键继续
    closegraph();			// 关闭绘图窗口
    return 0;
#endif // !DEBUG_UI
#ifndef DEBUG_MAIN
    
    metro_graph m;
    m.read_data();
    m.make_graph();
    m.serach_least_dis("苹果园", "西直门");
    cout << endl;
    m.serach_least_time("苹果园", "西直门");
    cout << endl;
    m.serach_least_trans("苹果园", "西直门");
#endif // !DEBUG_MAIN
    Window window(502, 420);
    window.messageLoop();
    return 0;
}

