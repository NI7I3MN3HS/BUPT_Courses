#include "Widget.h"

Widget::Widget(const int& x, const int& y, const int& width, const int& height) : x(x), y(y), width(width), height(height)
{
}

const int& Widget::getX() const
{
	// TODO: �ڴ˴����� return ���
	return x;
}

const int& Widget::getY() const
{
	// TODO: �ڴ˴����� return ���
	return y;
}

const int& Widget::getWidth() const
{
	// TODO: �ڴ˴����� return ���
	return width;
}

const int& Widget::getHeight() const
{
	// TODO: �ڴ˴����� return ���
	return height;
}

void Widget::setX(const int& x)
{
	this->x = x;
	show();
}

void Widget::setY(const int& y)
{
	this->y = y;
	show();
}

void Widget::setWidth(const int& width)
{
	this->width = width;
	show();
}

void Widget::setHeight(const int& height)
{
	this->height = height;
	show();
}

void Widget::setRect(const int& x, const int& y, const int& width, const int& height)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	show();
}
