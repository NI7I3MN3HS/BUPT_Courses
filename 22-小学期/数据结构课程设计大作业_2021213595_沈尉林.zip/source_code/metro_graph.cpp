#include"metro_graph.h"
#include"Window.h"
#define DEBUG1
#define DEBUG2
//��ѯ�ӿ�
string metro_graph::serach_least_dis(string s_name, string e_name)
{
	vector<int> stations_list;
	vector<int> edges_list;
	vector<int> s1=find_station_id(s_name);
	vector<int> s2 =find_station_id(e_name);
	Info prt;
	dijkstra_dist(s1[0], s2[0], stations_list, edges_list ,prt);
	string text;
	text = s_name + "��" + e_name + "·����̵�·����\n";
	for (int i = stations_list.size() - 1; i >= 0; --i)
	{
		if (i < (stations_list.size() - 1))
		{
			text += "\n  ��\n";
		}
		text += Stations[stations_list[i]].name;
		if (i == stations_list.size() - 1)
		{
			//Stations[stations_list[i]].lines_info
			text = text + " " + "����" + Lines[edges_list[i-1]].name;
		}
		if (i != stations_list.size() - 1 && i != 0)
		{
			/*
			if (Stations[stations_list[i]].lines_info != Stations[stations_list[i + 1]].lines_info)
			{
				text = text + " " + "����" + Lines[Stations[stations_list[i]].lines_info].name;
			}
			*/
			if (edges_list[i] != edges_list[i - 1])
			{
				text = text + " " + "����" + Lines[edges_list[i - 1]].name;
			}
		}
	}
	text += "\n";
	text = text + "Ԥ��·��Ϊ:" + to_string(prt.dist / 1000) + "����\n";
	//cout << "Ԥ��·��Ϊ:" << (prt.dist / 1000) << "����" << endl;
	text = text + "Ԥ��ʱ��Ϊ:" + to_string(prt.time) + "����\n";
	//cout << "Ԥ��ʱ��Ϊ:" << prt.time << "����" << endl;
	text = text + "Ԥ�Ʒ���Ϊ:" + to_string(prt.cost) + "Ԫ\n";
	text += "\n";
	//cout << "Ԥ�Ʒ���Ϊ:" << prt.cost << "Ԫ" << endl;
	cout << text;
	return text;
}

string metro_graph::serach_least_trans(string s_name, string e_name)
{
	vector<int> stations_list;
	vector<int> edges_list;
	vector<int> s1 = find_station_id(s_name);
	vector<int> s2 = find_station_id(e_name);
	Info prt;
	least_trans(s1[0], s2[0], stations_list, edges_list, prt);
	string text;
	text = s_name + "��" + e_name + "�������ٵ�·����\n";
	for (int i = stations_list.size() - 1; i >= 0; --i)
	{
		if (i < (stations_list.size() - 1))
		{
			text += "\n  ��\n";
		}
		text += Stations[stations_list[i]].name;
		if (i == stations_list.size() - 1)
		{
			text = text + " " + "����" + Lines[edges_list[i - 1]].name;
			//text = text + " " + "����" + Lines[Stations[stations_list[i]].lines_info].name;
		}
		if (i != stations_list.size() - 1 && i != 0)
		{
			if (edges_list[i] != edges_list[i - 1])
			{
				text = text + " " + "����" + Lines[edges_list[i - 1]].name;
			}
		}
	}
	text+="\n";
	text = text + "Ԥ��·��Ϊ:" + to_string(prt.dist / 1000) + "����\n";
	//cout << "Ԥ��·��Ϊ:" << (prt.dist / 1000) << "����" << endl;
	text = text + "Ԥ��ʱ��Ϊ:" + to_string(prt.time) + "����\n";
	//cout << "Ԥ��ʱ��Ϊ:" << prt.time << "����" << endl;
	text = text + "Ԥ�Ʒ���Ϊ:" + to_string(prt.cost) + "Ԫ\n";
	//cout << "Ԥ�Ʒ���Ϊ:" << prt.cost << "Ԫ" << endl;
	text += "\n";
	cout << text;
	return text;
}

string metro_graph::serach_least_time(string s_name, string e_name)
{
	RECT r = { 0, 0, 639, 479 };
	vector<int> stations_list;
	vector<int> edges_list;
	vector<int> s1 = find_station_id(s_name);
	vector<int> s2 = find_station_id(e_name);
	Info prt;
	dijkstra_time(s1[0], s2[0], stations_list,edges_list, prt);
	string text;
	text = s_name + "��" + e_name + "ʱ����̵�·����\n";
	for (int i = stations_list.size() - 1; i >= 0; --i)
	{
		if (i < (stations_list.size() - 1))
		{
			text += "\n  ��\n";
		}
		text += Stations[stations_list[i]].name;
		if (i == stations_list.size() - 1)
		{
			text = text + " " + "����" + Lines[edges_list[i - 1]].name;
			//text = text + " " + "����" + Lines[Stations[stations_list[i]].lines_info].name;
		}
		if (i != stations_list.size() - 1 && i != 0)
		{
			if (edges_list[i] != edges_list[i - 1])
			{
				text = text + " " + "����" + Lines[edges_list[i - 1]].name;
			}
		}
	}
	text += "\n";
	text = text + "Ԥ��·��Ϊ:" + to_string(prt.dist / 1000) + "����\n";
	//cout << "Ԥ��·��Ϊ:" << (prt.dist / 1000) << "����" << endl;
	text = text + "Ԥ��ʱ��Ϊ:" + to_string(prt.time) + "����\n";
	//cout << "Ԥ��ʱ��Ϊ:" << prt.time << "����" << endl;
	text = text + "Ԥ�Ʒ���Ϊ:" + to_string(prt.cost) + "Ԫ\n";
	//cout << "Ԥ�Ʒ���Ϊ:" << prt.cost << "Ԫ" << endl;
	cout << text;
	text += "\n";
	return text;
}

//����վ��

void metro_graph::add_new_station(string new_name,int LID)
{
	int SID;
	Station Sta;
	Sta.name=new_name;
	SID = Sta.id = Stations.size();//վ��Ψһid
	stations_hash[Sta.name].push_back(SID);//����վid����vector
	Stations.push_back(Sta);
	Stations[SID].lines_info = LID;//��վ������·
}

void metro_graph::add_line()
{
	string line_name, start_name, end_name;
	int LID,tem_dist,tem_time;
	cout << "���������������·:" << endl;
	cin >> line_name;
	LID = lines_hash[line_name];
	cout << "���������:" <<endl;
	cin >> start_name;
	cout << "�������յ�:" << endl;
	cin >> end_name;
	cout<<"������վ������վ��ʱ��" << endl;
	cin >> tem_dist>>tem_time;
	if (!stations_hash.count(start_name))
	{
		add_new_station(start_name, LID);
	}
	if (!stations_hash.count(end_name))
	{
		add_new_station(end_name, LID);
	}
	vector<int> tem_SID = find_station_id(start_name);
	vector<int> tem_EID = find_station_id(end_name);
	for (auto& l1 : tem_SID)
	{
		for (auto& l2 : tem_EID)
		{
			insert_edge(l1, l2, tem_dist, tem_time, LID);
		}
	}
}


//ɾ��վ��
void metro_graph::remove_station()
{
	cout << "�����Ƿ�" << endl;
}

//��ͼ
void metro_graph::make_graph()
{
	Graph.clear();
	Graph = vector<vector<Node>>(Stations.size(), vector<Node>());
	for (auto& a : Edges)
	{
		double dist = a.dist;
		double time = a.time;
		Graph[a.first].push_back(Node(a.second, dist, time));
		Graph[a.second].push_back(Node(a.first, dist, time));
	}
#ifndef DEBUG2
	fstream tOut;
	tOut.open("tOut1.txt", ios::out);
	for (auto& s1 : Stations)
	{
		for (auto& s2 : Graph[s1.id])
			tOut<<s1.id<<","<<s2.to<<"," << s2.dist << "," << s2.time << endl;
	}
	tOut.close();
#endif // !DEBUG2
}

//���ӱ�
void metro_graph::insert_edge(int n1,int n2,double dist,double time,int line_id)
{
	Edges.push_back(Edge(n1,n2,dist,time,line_id));
}

//��������
void metro_graph::read_data()
{
	fstream In,tOut;
	In.open("data_station_gbk.txt", ios::in);
	In >> total_lines;
	for (int i=0;i<total_lines;i++)
	{
		int LID,SID;
		Line Lin;
		In >>Lin.name >> Lin.total_station;
		LID = lines_hash[Lin.name] = Lin.id = Lines.size();//��·���
		Lines.push_back(Lin);
		for (int j = 0;j < Lin.total_station;j++)
		{
			Station Sta;
			In >> Sta.name;
			SID = Sta.id=Stations.size();//վ��Ψһid
			stations_hash[Sta.name].push_back(SID);//����վid����vector
			Stations.push_back(Sta);
			Stations[SID].lines_info = LID;//��վ������·
		}
	}
	In.close();
	
	In.open("data_in_gbk.txt", ios::in);
	for (int i = 0; i < Lines.size(); i++)
	{
		int total_station, line_id;
		string line_name;
		line_id=Lines[i].id;
		//cout << line_id<<endl;
		In >> line_name >> total_station;
		for (int j = 0; j < total_station ;j++)
		{
			double dist, time;
			string name1, name2;
			vector<int> li_info1,li_info2;
			In >> name1;
			In >> name2;
			In>> dist >> time;

			li_info1 = find_station_id(name1);
			li_info2 = find_station_id(name2);

			for (auto& l1 : li_info1)
			{
				for (auto& l2 : li_info2)
				{
					insert_edge(l1, l2, dist, time,line_id);
				}
			}
		}
	}
	In.close();

#ifndef DEBUG1

	tOut.open("tout.txt", ios::out);
	for (int i = 0; i < Stations.size(); i++)
	{
		tOut << Stations[i].name << "," << Stations[i].id << "," << Stations[i].lines_info << endl;
	}
	vector<bool> vis(Stations.size(), 1);
	for (int i = 0; i < Stations.size(); i++)
	{
		if (vis[i])
		{
			tOut << Stations[i].name << ":";
			for (auto& h : stations_hash[Stations[i].name])
			{
				tOut << h << " ";
			}
			tOut << endl;
			vis[i] = 0;
		}
	}
	for (auto& e : Edges)
	{
		tOut << e.first << "," << e.second << "," << e.dist << "," << e.time <<","<<e.line_id << endl;
	}
	tOut.close();
#endif // !DEBUG1

}

//���·�㷨
bool metro_graph::dijkstra_dist(int start, int end, vector<int>& stations_list, vector<int>& edges_list,Info & prt)
{
	#define INF 19260801 //���������
	stations_list.clear();
	edges_list.clear();

	if (start == end)
	{
		stations_list.push_back(end);
		stations_list.push_back(start);
		return true;
	}
	//��ʼ��
	//make_graph();//ͼ
	vector<int> path(Stations.size(), -1);//·��
	vector<double> dist(Stations.size(), INF);//dist��ʼ�� ���Ϊ0������Ϊ������
	vector<double> time(Stations.size(), INF);//dist��ʼ�� ���Ϊ0������Ϊ������
	dist[start] = 0;
	time[start] = 0;

	priority_queue<Node, vector<Node>, cmp1 >priq;//���·���ȶ���
	priq.push(Node(start, 0, 0));
	while (!priq.empty())
	{
		Node top = priq.top();
		priq.pop();
		if (top.to == end)//�����յ㣬�˳�
		{
			break;
		}
		for (int i = 0; i < Graph[top.to].size(); ++i)
		{
			Node& t = Graph[top.to][i];
			if (top.dist + t.dist < dist[t.to])//�������·��
			{
				path[t.to] = top.to;
				dist[t.to] = top.dist + t.dist;
				time[t.to] = top.time + t.time;
				priq.push(Node(t.to, dist[t.to], time[t.to]));
			}
		}
	}
	if (path[end] == -1)
	{
		return false;//���ɵ���
	}
	int p = end;
	while (path[p] != -1)
	{
		stations_list.push_back(p);
		int e = edges_line_info(path[p], p);
		edges_list.push_back(e);
		p = path[p];
	}
	stations_list.push_back(start);
	prt.dist = dist[end];
	prt.time = time[end];
	prt.cost = price(prt.dist);
	return true;
}

bool metro_graph::dijkstra_time(int start, int end, vector<int>& stations_list,vector<int>& edges_list, Info& prt)
{
	#define INF 19260801 //���������
	stations_list.clear();
	edges_list.clear();
	//cout <<start<< "," << end<<endl;
	if (start == end)
	{
		stations_list.push_back(end);
		stations_list.push_back(start);
		return true;
	}
	//��ʼ��
	//make_graph();//ͼ
	vector<int> path(Stations.size(), -1);//·��
	vector<double> dist(Stations.size(), INF);//dist��ʼ�� ���Ϊ0������Ϊ������
	vector<double> time(Stations.size(), INF);//dist��ʼ�� ���Ϊ0������Ϊ������
	time[start] = 0;
	dist[start] = 0;

	priority_queue<Node, vector<Node>, cmp2 >priq;//���·���ȶ���
	priq.push(Node(start, 0, 0));
	while (!priq.empty())
	{
		Node top = priq.top();
		priq.pop();
		if (top.to == end)//�����յ㣬�˳�
		{
			break;
		}
		for (int i = 0; i < Graph[top.to].size(); ++i)
		{
			Node& t = Graph[top.to][i];
			if (top.time + t.time < time[t.to])//�������·��
			{
				path[t.to] = top.to;
				dist[t.to] = top.dist + t.dist;
				time[t.to] = top.time + t.time;
				priq.push(Node(t.to, dist[t.to], time[t.to]));
			}
		}
	}
	if (path[end] == -1)
	{
		return false;//���ɵ���
	}
	int p = end;
	while (path[p] != -1)
	{
		stations_list.push_back(p);
		int e = edges_line_info(path[p], p);
		edges_list.push_back(e);
		p = path[p];
	}
	stations_list.push_back(start);
	prt.dist = dist[end];
	prt.time = time[end];
	prt.cost = price(prt.dist);
	return true;
}

bool metro_graph::least_trans(int start, int end, vector<int>& stations_list, vector<int>& edges_list,Info& prt)
{
	
	stations_list.clear();
	edges_list.clear();
	if (start == end)
	{
		stations_list.push_back(end);
		stations_list.push_back(start);
		return true;
	}
	vector<int> path(Stations.size(), -1);//·��
	vector<double> dist(Stations.size(), INF);//dist��ʼ�� ���Ϊ0������Ϊ������
	vector<double> time(Stations.size(), INF);//time��ʼ�� ���Ϊ0������Ϊ������
	vector<double> cost(Stations.size(), INF);//cost��ʼ�� ���Ϊ1������Ϊ������
	cost[start] = 1;
	time[start] = 0;

	priority_queue<Node, vector<Node>, cmp3 >priq;//���·���ȶ���
	priq.push(Node(start, 0, 0));
	while (!priq.empty())
	{
		Node top = priq.top();
		priq.pop();
		if (top.to == end)//�����յ㣬�˳�
		{
			break;
		}
		for (int i = 0; i < Graph[top.to].size(); ++i)
		{
			Node& t = Graph[top.to][i];
			int trans_cost=0;
			if (Stations[top.to].lines_info != Stations[t.to].lines_info)
			{
				trans_cost += 10;
			}
			if (top.cost + t.cost + trans_cost < cost[t.to])//�������·��
			{
				path[t.to] = top.to;
				dist[t.to] = top.dist + t.dist;
				time[t.to] = top.time + t.time;
				cost[t.to] = top.cost + t.cost;
				priq.push(Node(t.to, dist[t.to], time[t.to]));
			}
		}
	}
	if (path[end] == -1)
	{
		return false;//���ɵ���
	}
	int p = end;
	while (path[p] != -1)
	{
		stations_list.push_back(p);
		int e = edges_line_info(path[p], p);
		edges_list.push_back(e);
		p = path[p];
	}
	stations_list.push_back(start);
	prt.dist = dist[end];
	prt.time = time[end];
	prt.cost = price(prt.dist);
	return true;
}

//�ƷѺ���
int metro_graph::price(double dist)
{
	if (dist <= 6000) return 3;
	else if (dist <= 12000) return 4;
	else if (dist <= 22000) return 5;
	else if (dist <= 32000) return 6;
	else
	{
		return (6 + ceil((dist - 32000) / 20000));
	}
}

//��ȡվ��id����
vector<int> metro_graph::find_station_id(string station)
{
	return stations_hash[station];
}

//��ȡ�ߵ���·id
int metro_graph::edges_line_info(int n1, int n2)
{
	for (auto& e : Edges)
	{
		if ((e.first == n1 && e.second == n2) || (e.first == n2 && e.second == n1))
		{
			return e.line_id;
		}
		
	}
}
