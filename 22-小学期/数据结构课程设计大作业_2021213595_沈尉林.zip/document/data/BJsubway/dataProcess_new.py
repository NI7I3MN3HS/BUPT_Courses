from encodings import utf_8
import os
path = os.path.dirname(os.path.realpath(__file__))

def dataStation() :
    f = open(path + "//data_station.TXT", encoding = "utf_8", mode = "w") 

    data_str = ""
    subway_num = 0
    station_num = 0
    str_station = ""
    cache_line = ""

    for line in open(path + "//Data.TXT", encoding = "utf_8"):
        if line == '\n' :
            str_station += cache_line[1] + '\n'
            station_num += 1
            data_str += str(station_num) + '\n' + str_station + '\n'
            continue

        # A new subway route 
        if line[0] == '#' :
            signal = True
            station_num = 0; subway_num += 1
            continue

        # Read in speed
        if signal == True :
            l = line.split('\t')
            signal = False; str_station = ""
            data_str += l[0] + '\n'
            continue
        
        line = line.strip()
        l = line.split('\t')
        cache_line = l
        str_station += l[0] + '\n'
        station_num += 1
        # Unit : minute

    data_str = str(subway_num) + '\n\n' + data_str
    f.write(data_str)
    f.close()

def dataIn() :
    f = open(path + "//data_in.TXT", encoding = "utf_8", mode = "w") 
    data_str = ""
    station_num = 0
    str_station = ""
    for line in open(path + "//Data.TXT", encoding = "utf_8"):
        if line == '' :
            break

        if line == '\n' :
            data_str += str(station_num) + '\n' + str_station + '\n'
            continue

        # A new subway route 
        if line[0] == '#' :
            str_station = ""
            station_num = 0
            signal = True
            continue

        # Read in speed
        if signal == True :
            line = line.strip('\n')
            l = line.split('\t')
            data_str += l[0] + '\n'
            speed = float(l[1]); speed /= 2
            signal = False; 
            continue
    
        line = line.strip()
        l = line.split('\t')
        dist = int(l[2])
        # Unit : minute
        time = format((dist / (speed / 3.6)) / 60,'.2f')
        str_station += l[0] + '\n' + l[1] + '\n' + l[2] + ' ' + str(time) + '\n'
        station_num += 1

    f.write(data_str)

if __name__ == "__main__" :    
    dataStation()
    dataIn()

