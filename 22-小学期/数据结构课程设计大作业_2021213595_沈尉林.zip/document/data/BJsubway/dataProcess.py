from encodings import utf_8
import os
path = os.path.dirname(os.path.realpath(__file__))

f = open(path + "//finalData.TXT", encoding = "utf_8", mode = "w") 

signal = False
speed = 0

for line in open(path + "//Data.TXT", encoding = "utf_8"):
    if line == '\n' :
        f.writelines(line); continue

    # A new subway route 
    if line[0] == '#' :
        f.write(line); signal = True
        continue

    # Read in speed
    if signal == True :
        line = line.strip('\n')
        f.writelines(line + "km/h" + '\n')
        l = line.split('\t')
        speed = float(l[1]); speed /= 2
        signal = False; 
        continue
    
    line = line.strip()
    l = line.split('\t')
    dist = int(l[2])
    # Unit : minute
    time = format((dist / (speed / 3.6)) / 60,'.2f')
    line = line + '\t' + str(time) + 'min\n'
    f.write(line)
    

