﻿#include<iostream>
using namespace std;
//二叉树结点
struct BiNode
{
    int data;//结点数据
    BiNode* lchild;//左子树
    BiNode* rchild;//右子树
};
//二叉树类
class BiTree
{
private:
    BiNode* CreatBitree();//创建二叉树
    void ReleaseBitree(BiNode* R);//释放二叉树
public:
    BiNode* root;//根节点
    BiTree();//构造函数
    ~BiTree();//析构函数
    void VLR(BiNode* R);//前序遍历
    void LDR(BiNode* R);//中序遍历
    void LRD(BiNode* R);//后序遍历
};
BiNode* BiTree::CreatBitree()//先序创建二叉树
{
    BiNode* R;//创建根结点
    int temp;//临时读入数据
    cin >> temp;
    if(temp==0)//读入为0说明为空结点
    {
        R = nullptr;
    }
    else
    {
        R = new BiNode;//申请空间
        R->data = temp;
        R->lchild = CreatBitree();//递归创建左子树
        R->rchild = CreatBitree();//递归创建右子树
    }
    return R;
}
BiTree::BiTree()//构造函数
{
    root = CreatBitree();
}
void BiTree::ReleaseBitree(BiNode* R)
{
    if (R != nullptr)
    {
        ReleaseBitree(R->lchild);
        ReleaseBitree(R->rchild);
        delete R;
    }
}
BiTree::~BiTree()//析构函数
{
    ReleaseBitree(root);
}
void BiTree::VLR(BiNode* R)//先序遍历
{
    if(R != nullptr)
    {
        cout << R->data<<" ";
        VLR(R->lchild);
        VLR(R->rchild);
    }
}
void BiTree::LDR(BiNode* R)//中序遍历
{
    if (R != nullptr)
    {
        LDR(R->lchild);
        cout << R->data<<" ";
        LDR(R->rchild);
    }
}
void BiTree::LRD(BiNode* R)//后序遍历
{
    if (R != nullptr)
    {
        LRD(R->lchild);
        LRD(R->rchild);
        cout << R->data<<" ";
    }
}
int main()
{
    cout << "键盘读入如下:" << endl;
    BiTree bt;
    cout << endl;
    cout << "前序遍历结果：";
    bt.VLR(bt.root);
    cout << endl;
    cout << "中序遍历结果：";
    bt.LDR(bt.root);
    cout << endl;
    cout << "后序遍历结果：";
    bt.LRD(bt.root);
    cout << endl;
    system("pause");
    return 0;
}