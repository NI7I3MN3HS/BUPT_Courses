﻿#include <ctime>
#include <random>
#include<fstream>
using namespace std;
int main() 
{
    fstream f1,f2,f3,f4,f5;
    f1.open("randomnumber1.txt", ios::out);
    f2.open("randomnumber2.txt", ios::out);
    f3.open("randomnumber3.txt", ios::out);
    f4.open("randomnumber4.txt", ios::out);
    f5.open("randomnumber5.txt", ios::out);
    static default_random_engine Engine;//随机数生成引擎
    static uniform_int_distribution<int> RandomNumber(1, 1000); // 左值为下界，右值为上界
    Engine.seed(time(0));//使用时间作为随机数种子
    //生成5组不同数量的随机数
    for (int i = 0; i < 100; i++)
    {
        f1<< RandomNumber(Engine)<<" ";
    }
    for (int i = 0; i < 500; i++)
    {
        f2 << RandomNumber(Engine) << " ";
    }
    for (int i = 0; i < 1000; i++)
    {
        f3 << RandomNumber(Engine) << " ";
    }
    for (int i = 0; i < 5000; i++)
    {
        f4 << RandomNumber(Engine) << " ";
    }
    for (int i = 0; i < 10000; i++)
    {
        f5 << RandomNumber(Engine) << " ";
    }
    f1.close();
    f2.close();
    f3.close();
    f4.close();
    f5.close();
    return 0;
}