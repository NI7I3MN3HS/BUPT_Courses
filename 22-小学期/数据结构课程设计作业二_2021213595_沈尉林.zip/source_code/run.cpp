﻿#include<iostream>
#include<algorithm>
#include<fstream>
#include<cmath>
#include<Windows.h>
using namespace std;
//#define DEBUG1
//#define DEBUG2
//MyTimer.h// 
#ifndef __MyTimer_H__  
#define __MyTimer_H__  
class MyTimer
{
private:
	int _freq;
	LARGE_INTEGER _begin;
	LARGE_INTEGER _end;

public:
	long costTime;      // 花费的时间(精确到微秒)  

public:
	MyTimer()
	{
		LARGE_INTEGER tmp;
		QueryPerformanceFrequency(&tmp);//QueryPerformanceFrequency()作用：返回硬件支持的高精度计数器的频率。  

		_freq = tmp.QuadPart;
		costTime = 0;
	}

	void Start()      // 开始计时  
	{
		QueryPerformanceCounter(&_begin);//获得初始值  
	}

	void End()        // 结束计时  
	{
		QueryPerformanceCounter(&_end);//获得终止值  
		costTime = (long)((_end.QuadPart - _begin.QuadPart) * 1000000 / _freq);
	}

	void Reset()      // 计时清0  
	{
		costTime = 0;
	}
};
#endif
struct SeqList
{
	int length;//顺序表长度
	int data[10005];
};
int stack1[10005],stack2[10005];//临时数组
int temp[10005];//归并排序临时数组
int flag=1;//小规模数据打印趟数
int quick=1;//标记快排前五趟输出
int depth;//记录归并递归深度
int move1,compare1,move2, compare2,move3,compare3,move4,compare4,move5,compare5;//记录关键字比较次数和移动次数
void InsertSort(SeqList arr)//直接插入排序
{
	int i, j;
	for (i = 2; i <= arr.length; i++)
	{
		compare1++;//比较次数+1
		if (arr.data[i] < arr.data[i - 1])
		{
			arr.data[0] = arr.data[i];//设置哨兵
			arr.data[i] = arr.data[i - 1];
			move1+=2;//后移移动次数加1,设置哨兵移动次数加1
			for (j = i - 2; arr.data[0] < arr.data[j]; j--)
			{
				arr.data[j + 1] = arr.data[j];
				move1++; //后移移动次数加1
				compare1++;//比较次数+1
			}
			arr.data[j + 1] = arr.data[0];//将原arr[i]插入正确位置
			move1++;
		}
		if (flag && i <= 6)
		{
			cout << "第" << i - 1 << "趟排序：" << endl;
			for (int i = 1; i <= arr.length; i++)
			{
				cout << arr.data[i] << " ";
			}
			cout << endl;
		}
	}
	if (flag)
	{
		cout << "最终结果:" << endl;
		for (int i = 1; i <= 100; i++)
		{
			cout << arr.data[i] << " ";
		}
		cout << endl;
	}
}
void Merge(int arr[],int l,int mid,int r)
{
	int k = 1, i = l, j = mid + 1;
	while (i <= mid and j <= r)
	{
		compare2++;
		if (arr[i] <= arr[j]) { temp[k++] = arr[i++]; move2++; }
		else { temp[k++] = arr[j++]; move2++; }
	}
	while (i <= mid) { temp[k++] = arr[i++]; move2++; }
	while (j <= r) { temp[k++] = arr[j++]; move2++; }
	for (i = l, j = 1; i <= r; i++, j++)
	{
		arr[i] = temp[j];
		move2++;
	}
}
void MergeSort(int arr[],int n)//二路归并排序(非递归)
{
	int p=1;
	//depth为组内元素个数,每归并一次乘二
	for (int depth = 2; depth / 2< n; depth*=2) 
	{
		//每depth个元素一组
		for (int i = 1; i <= n; i += depth) 
		{
			int mid = i + depth / 2 - 1;//depth/2为左子区间元素个数
			if (mid + 1 < n) //右子区间存在元素则合并 
			{
				Merge(arr, i, mid, min((i + depth - 1), n));
			}
		}
		if (flag && p <= 5)
		{
			cout << "第" <<p<< "趟排序：" << endl;
			for (int i = 1; i <=100; i++)
			{
				cout << stack1[i] << " ";
			}
			cout << endl;
		}
		p++;
	}
}
void MergeSort(int arr[], int l, int r)//二路归并排序(递归)
{
	if (l >= r) return;
	int mid = (l + r) >> 1;
	MergeSort(arr, l, mid); MergeSort(arr, mid + 1, r);
	int k = 1, i = l, j = mid+ 1;
	while (i <= mid and j <= r)
	{
		compare2++;
		if (arr[i] <= arr[j]) { temp[k++] = arr[i++]; move2++; }
		else { temp[k++] = arr[j++]; move2++; }
	}
	while (i <= mid) { temp[k++] = arr[i++]; move2++; }
	while (j <= r) {temp[k++] = arr[j++]; move2++; }
	for (i = l, j = 1; i <= r; i++, j++)
	{
		arr[i] = temp[j];
		move2++;
	}
}
void BubbleSort(SeqList arr)//起泡排序
{
	int p = 1;
	int pos = arr.length;
	while (pos != 0)
	{
		int bound = pos;//无序元素范围
		pos = 0;//每趟元素起始交换位置
		for (int i = 1; i < bound; i++)
		{
			compare3++;//比较次数+1
			if (arr.data[i] > arr.data[i + 1])
			{
				swap(arr.data[i], arr.data[i + 1]);
				move3 += 3;//元素交换，移动次数加3
				pos = i;
			}
		}
		if (flag && p <= 5)
		{
			cout << "第" << p << "趟排序：" << endl;
			for (int i = 1; i <= arr.length; i++)
			{
				cout << arr.data[i] << " ";
			}
			cout << endl;
			p++;
		}
	}
	if (flag)
	{
		cout << "最终结果:" << endl;
		for (int i = 1; i <= 100; i++)
		{
			cout << arr.data[i] << " ";
		}
		cout << endl;
	}
}
void QuickSort(int arr[], int l, int r)//快速排序
{
	if (l >= r) return;
	int x = arr[(l + r) >> 1];//选择轴值
	int i = l - 1, j = r + 1;//划分区域
	while (i < j)
	{
		do 
		{ i++; compare4++; }
		while (arr[i] < x);
		do 
		{ j--; compare4++; }
		while (arr[j] > x);
		if (i < j) { swap(arr[i], arr[j]); move4 += 3; }
	}
	if (flag && quick<=5)
	{
		cout << "第" << quick << "趟排序：" << endl;
		for (int i = 1; i <= 100; i++)
		{
			cout << arr[i] << " ";
		}
		cout << endl;
		quick++;
	}
	QuickSort(arr, l, j); QuickSort(arr, j + 1, r);
}
void SelectSort(SeqList &arr)//简单选择排序
{
	for (int i = 1; i < arr.length; i++)
	{
		//查找最小位置
		int index = i;
		for (int j = i + 1; j <= arr.length; j++)
		{
			compare5++;//比较次数+1
			if (arr.data[j] < arr.data[index])
			{
				index = j;
			}
		}
		//交换
		if (index != i)
		{
			swap(arr.data[i],arr.data[index]);
			move5 += 3;//元素交换，移动次数加3
		}
		if (flag && i <= 5)
		{
			cout << "第" << i << "趟排序：" << endl;
			for (int i = 1; i <= arr.length; i++)
			{
				cout << arr.data[i] << " ";
			}
			cout << endl;
		}
	}
	if (flag)
	{
		cout << "最终结果:" << endl;
		for (int i = 1; i <= 100; i++)
		{
			cout << arr.data[i] << " ";
		}
		cout << endl;
	}
}
int main()
{
	MyTimer timer;
	SeqList arr = {};
	fstream f1, f2, f3, f4, f5;
	f1.open("randomnumber1.txt", ios::in);
	f2.open("randomnumber2.txt", ios::in);
	f3.open("randomnumber3.txt", ios::in);
	f4.open("randomnumber4.txt", ios::in);
	f5.open("randomnumber5.txt", ios::in);
#ifndef DEBUG1
	/*------------------------------------------------*/
	cout << "数据规模100" << endl;
	arr.length = 100;
	for (int i = 1; i <= 100; i++)
	{
		f1 >> arr.data[i];
		stack1[i] = arr.data[i];
		stack2[i] = stack1[i];
	}
	f1.close();
	cout << "输入:" << endl;
	for (int i = 1; i <= arr.length; i++)
	{
		cout << arr.data[i] << " ";
	}
	cout << endl;
	//-----------------------
	cout << "排序方法:直接插入排序" << endl;
	timer.Start();
	InsertSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move1 << "  " << "关键字比较次数：" << compare1 << endl;
	timer.Reset();
	cout << endl;
	//----------------------
	cout << "排序方法:二路归并排序" << endl;
	timer.Start();
	MergeSort(stack1, 100);
	timer.End();
	cout << "最终结果:" << endl;
	for (int i = 1; i <= arr.length; i++)
	{
		cout << stack1[i] << " ";
	}
	cout << endl;
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move2 << "  " << "关键字比较次数：" << compare2 << endl;
	timer.Reset();
	cout << endl;
	//---------------------
	cout << "排序方法:起泡排序" << endl;
	timer.Start();
	BubbleSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move3 << "  " << "关键字比较次数：" << compare3 << endl;
	timer.Reset();
	cout << endl;
	//--------------------
	cout << "排序方法:快速排序" << endl;
	timer.Start();
	QuickSort(stack2, 1, arr.length);
	timer.End();
	cout << "最终结果:" << endl;
	for (int i = 1; i <= arr.length; i++)
	{
		cout << stack2[i] << " ";
	}
	cout << endl;
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move4 << "  " << "关键字比较次数：" << compare4 << endl;
	timer.Reset();
	cout << endl;
	//---------------------
	cout << "排序方法:简单选择排序" << endl;
	timer.Start();
	SelectSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move5 << "  " << "关键字比较次数：" << compare5 << endl;
	timer.Reset();
	cout << endl;
	move1 = 0, compare1 = 0, move2 = 0, compare2 = 0, move3 = 0, compare3 = 0, move4 = 0, compare4 = 0, move5 = 0, compare5 = 0;//重置计数器
#endif // !DEBUG1
	flag = 0;//数据规模较大不再输出前5步
#ifndef DEBUG2
/*------------------------------------------------*/
	cout << "数据规模500" << endl;
	for (int i = 1; i <= 500; i++)
	{
		f2 >> arr.data[i];
		stack1[i] = arr.data[i];
		stack2[i] = stack1[i];
	}
	arr.length = 500;
	f2.close();

	cout << "直接插入排序:" << endl;
	timer.Start();
	InsertSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move1 << "  " << "关键字比较次数：" << compare1 << endl;
	timer.Reset();

	cout << "二路归并排序:" << endl;
	timer.Start();
	MergeSort(stack1, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move2 << "  " << "关键字比较次数：" << compare2 << endl;
	timer.Reset();

	cout << "起泡排序:" << endl;
	timer.Start();
	BubbleSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move3 << "  " << "关键字比较次数：" << compare3 << endl;
	timer.Reset();

	cout << "快速排序:" << endl;
	timer.Start();
	QuickSort(stack2, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move4 << "  " << "关键字比较次数：" << compare4 << endl;
	timer.Reset();

	cout << "简单选择排序:" << endl;
	timer.Start();
	SelectSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move5 << "  " << "关键字比较次数：" << compare5 << endl;
	timer.Reset();
	cout << endl;
	move1 = 0, compare1 = 0, move2 = 0, compare2 = 0, move3 = 0, compare3 = 0, move4 = 0, compare4 = 0, move5 = 0, compare5 = 0;//重置计数器

/*------------------------------------------------*/
	cout << "数据规模1000" << endl;
	for (int i = 1; i <= 1000; i++)
	{
		f3 >> arr.data[i];
		stack1[i] = arr.data[i];
		stack2[i] = stack1[i];
	}
	f3.close();
	arr.length = 1000;
	cout << "直接插入排序:" << endl;
	timer.Start();
	InsertSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move1 << "  " << "关键字比较次数：" << compare1 << endl;
	timer.Reset();

	cout << "二路归并排序:" << endl;
	timer.Start();
	MergeSort(stack1, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move2 << "  " << "关键字比较次数：" << compare2 << endl;
	timer.Reset();

	cout << "起泡排序:" << endl;
	timer.Start();
	BubbleSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move3 << "  " << "关键字比较次数：" << compare3 << endl;
	timer.Reset();

	cout << "快速排序:" << endl;
	timer.Start();
	QuickSort(stack2, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move4 << "  " << "关键字比较次数：" << compare4 << endl;
	timer.Reset();

	cout << "简单选择排序:" << endl;
	timer.Start();
	SelectSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move5 << "  " << "关键字比较次数：" << compare5 << endl;
	timer.Reset();
	cout << endl;
	move1 = 0, compare1 = 0, move2 = 0, compare2 = 0, move3 = 0, compare3 = 0, move4 = 0, compare4 = 0, move5 = 0, compare5 = 0;//重置计数器

/*------------------------------------------------*/
	cout << "数据规模5000" << endl;
	for (int i = 1; i <= 5000; i++)
	{
		f4 >> arr.data[i];
		stack1[i] = arr.data[i];
		stack2[i] = stack1[i];
	}
	arr.length = 5000;
	f4.close();
	cout << "直接插入排序:" << endl;
	timer.Start();
	InsertSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move1 << "  " << "关键字比较次数：" << compare1 << endl;
	timer.Reset();

	cout << "二路归并排序:" << endl;
	timer.Start();
	MergeSort(stack1, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move2 << "  " << "关键字比较次数：" << compare2 << endl;
	timer.Reset();

	cout << "起泡排序:" << endl;
	timer.Start();
	BubbleSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move3 << "  " << "关键字比较次数：" << compare3 << endl;
	timer.Reset();

	cout << "快速排序:" << endl;
	timer.Start();
	QuickSort(stack2, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move4 << "  " << "关键字比较次数：" << compare4 << endl;
	timer.Reset();

	cout << "简单选择排序:" << endl;
	timer.Start();
	SelectSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move5 << "  " << "关键字比较次数：" << compare5 << endl;
	timer.Reset();
	cout << endl;
	move1 = 0, compare1 = 0, move2 = 0, compare2 = 0, move3 = 0, compare3 = 0, move4 = 0, compare4 = 0, move5 = 0, compare5 = 0;//重置计数器

	
	/*------------------------------------------------*/
	cout << "数据规模10000" << endl;
	for (int i = 1; i <= 10000; i++)
	{
		f5 >> arr.data[i];
		stack1[i] = arr.data[i];
		stack2[i] = stack1[i];
	}
	arr.length = 10000;
	cout << "直接插入排序:" << endl;
	timer.Start();
	InsertSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move1 << "  " << "关键字比较次数：" << compare1 << endl;
	timer.Reset();

	cout << "二路归并排序:" << endl;
	timer.Start();
	MergeSort(stack1, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move2 << "  " << "关键字比较次数：" << compare2 << endl;
	timer.Reset();

	cout << "起泡排序:" << endl;
	timer.Start();
	BubbleSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move3 << "  " << "关键字比较次数：" << compare3 << endl;
	timer.Reset();

	cout << "快速排序:" << endl;
	timer.Start();
	QuickSort(stack2, 1, arr.length);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move4 << "  " << "关键字比较次数：" << compare4 << endl;
	timer.Reset();

	cout << "简单选择排序:" << endl;
	timer.Start();
	SelectSort(arr);
	timer.End();
	cout << "运行时间:" << timer.costTime << "us" << endl;
	cout << "关键字移动次数:" << move5 << "  " << "关键字比较次数：" << compare5 << endl;
	timer.Reset();
	cout << endl;
	f5.close();
	move1 = 0, compare1 = 0, move2 = 0, compare2 = 0, move3 = 0, compare3 = 0, move4 = 0, compare4 = 0, move5 = 0, compare5 = 0;//重置计数器
#endif // !DEBUG2
	system("pause");
}